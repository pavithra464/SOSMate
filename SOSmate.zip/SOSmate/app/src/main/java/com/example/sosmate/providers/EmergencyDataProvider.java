package com.example.sosmate.providers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

public class EmergencyDataProvider extends ContentProvider {

    private static final String TAG = "EmergencyDataProvider";

    // Authority (defined in AndroidManifest.xml)
    public static final String AUTHORITY = "com.example.sosmate.emergencydata";

    // Base URI
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/data");

    // UriMatcher codes
    private static final int DATA = 1;
    private static final int DATA_ID = 2;

    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        uriMatcher.addURI(AUTHORITY, "data", DATA);
        uriMatcher.addURI(AUTHORITY, "data/#", DATA_ID);
    }

    @Override
    public boolean onCreate() {
        Log.d(TAG, "EmergencyDataProvider created");
        // TODO: Initialize database or storage here
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        Log.d(TAG, "Query request: " + uri);
        // TODO: Return data from database
        return null;
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case DATA:
                return "vnd.android.cursor.dir/vnd." + AUTHORITY + ".data";
            case DATA_ID:
                return "vnd.android.cursor.item/vnd." + AUTHORITY + ".data";
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.d(TAG, "Insert request: " + uri);
        // TODO: Insert data into database
        long id = 1; // Replace with real rowId
        return ContentUris.withAppendedId(CONTENT_URI, id);
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        Log.d(TAG, "Delete request: " + uri);
        // TODO: Delete data from database
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        Log.d(TAG, "Update request: " + uri);
        // TODO: Update data in database
        return 0;
    }
}