package com.example.sosmate.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.sosmate.R;
import com.example.sosmate.services.EmergencyService;

public class EmergencyTriggerActivity extends AppCompatActivity {

    private String emergencyType;
    private TextView emergencyTitle;
    private TextView emergencyMessage;
    private ProgressBar progressEmergency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Create a transparent overlay-like view
        setContentView(R.layout.activity_emergency_trigger);
        
        // Initialize views
        emergencyTitle = findViewById(R.id.tv_emergency_title);
        emergencyMessage = findViewById(R.id.tv_emergency_message);
        progressEmergency = findViewById(R.id.progress_emergency);
        
        // Get the emergency type from intent
        emergencyType = getIntent().getStringExtra("emergency_type");
        
        // Trigger appropriate emergency based on type
        if (emergencyType != null) {
            switch (emergencyType) {
                case "SOS":
                    triggerEmergencySOS();
                    break;
                case "PANIC":
                    triggerPanicAlert();
                    break;
                case "FAKE_CALL":
                    // This case is handled by FakeCallActivity now
                    finish();
                    break;
                case "SHARE_LOCATION":
                    // This case is handled by LocationHistoryActivity now
                    finish();
                    break;
                case "SAFETY_CHECKIN":
                    // This case is handled by EmergencyContactsActivity now
                    finish();
                    break;
                default:
                    Toast.makeText(this, "Unknown emergency type", Toast.LENGTH_SHORT).show();
                    finish();
                    break;
            }
        } else {
            Toast.makeText(this, "Emergency type not specified", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void triggerEmergencySOS() {
        // Update UI to show SOS
        emergencyTitle.setText("EMERGENCY SOS ACTIVATED");
        emergencyTitle.setTextColor(getColor(R.color.emergency_red));
        emergencyMessage.setText("Emergency services have been notified. Help is on the way.");
        
        // Start the emergency service
        Intent serviceIntent = new Intent(this, EmergencyService.class);
        startService(serviceIntent);
        
        // Schedule to finish after 3 seconds
        new Handler().postDelayed(() -> finish(), 3000);
    }

    private void triggerPanicAlert() {
        // Update UI to show panic alert
        emergencyTitle.setText("PANIC ALERT ACTIVATED");
        emergencyTitle.setTextColor(getColor(R.color.panic_orange));
        emergencyMessage.setText("Alerting your emergency contacts and tracking your location.");
        
        // Start the emergency service
        Intent serviceIntent = new Intent(this, EmergencyService.class);
        startService(serviceIntent);
        
        // Schedule to finish after 3 seconds
        new Handler().postDelayed(() -> finish(), 3000);
    }
}