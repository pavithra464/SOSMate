package com.example.sosmate.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sosmate.R;
import com.example.sosmate.database.DatabaseHelper;
import com.example.sosmate.models.EmergencyContact;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class ContactsFragment extends Fragment {

    private RecyclerView recyclerView;
    private FloatingActionButton fabAddContact;
    private ContactAdapter adapter;
    private List<EmergencyContact> contactsList;
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contacts, container, false);

        initializeViews(view);
        databaseHelper = DatabaseHelper.getInstance(requireContext());
        loadContacts();
        setupRecyclerView();
        setupClickListeners();

        return view;
    }

    private void initializeViews(View view) {
        recyclerView = view.findViewById(R.id.recycler_contacts);
        fabAddContact = view.findViewById(R.id.fab_add_contact);
    }

    // ✅ Fetch all contacts from the SQLite database
    private void loadContacts() {
        contactsList = databaseHelper.getAllContacts();
        if (contactsList == null || contactsList.isEmpty()) {
            Toast.makeText(requireContext(), "No contacts found. Add one!", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ContactAdapter(contactsList, contact -> showContactOptions(contact), databaseHelper);
        recyclerView.setAdapter(adapter);
    }

    private void setupClickListeners() {
        fabAddContact.setOnClickListener(v -> showAddContactDialog());
    }

    // ✅ Add new contact and refresh list
    private void showAddContactDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_contact, null);

        com.google.android.material.textfield.TextInputEditText nameInput = dialogView.findViewById(R.id.input_name);
        com.google.android.material.textfield.TextInputEditText phoneInput = dialogView.findViewById(R.id.input_phone);
        com.google.android.material.textfield.TextInputEditText relationshipInput = dialogView.findViewById(R.id.input_relationship);

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setView(dialogView);
        builder.setTitle("Add Emergency Contact");
        builder.setCancelable(false);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String name = nameInput.getText().toString().trim();
            String phone = phoneInput.getText().toString().trim();
            if (!phone.startsWith("+")) {
                phone = "+91" + phone;
            }
            String relation = relationshipInput.getText().toString().trim();

            if (name.isEmpty() || phone.isEmpty() || relation.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Save contact to SQLite
            EmergencyContact newContact = new EmergencyContact(name, phone, relation, contactsList.size() + 1);
            databaseHelper.addContact(newContact);

            // ✅ Refresh from DB instead of just appending
            refreshContactList();

            Toast.makeText(requireContext(), "Contact added successfully!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // ✅ Reload contacts from database
    private void refreshContactList() {
        contactsList.clear();
        contactsList.addAll(databaseHelper.getAllContacts());
        adapter.notifyDataSetChanged();
    }

    private void showContactOptions(EmergencyContact contact) {
        String[] options = {"Call Contact", "Send SMS"};
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle(contact.getName());
        builder.setItems(options, (dialog, which) -> {
            if (which == 0) {
                String phoneNumber = contact.getPhoneNumber();
                if (!phoneNumber.startsWith("+")) {
                    phoneNumber = "+91" + phoneNumber;
                }
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber));
                startActivity(callIntent);
            } else if (which == 1) {
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                smsIntent.setData(Uri.parse("sms:" + contact.getPhoneNumber()));
                startActivity(smsIntent);
            }
        });
        builder.show();
    }

    // ✅ RecyclerView Adapter with edit/delete functionality
    public static class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactViewHolder> {
        private final List<EmergencyContact> contacts;
        private final ContactsFragment.OnContactClickListener listener;
        private final DatabaseHelper databaseHelper;

        public ContactAdapter(List<EmergencyContact> contacts, ContactsFragment.OnContactClickListener listener, DatabaseHelper databaseHelper) {
            this.contacts = contacts;
            this.listener = listener;
            this.databaseHelper = databaseHelper;
        }

        @NonNull
        @Override
        public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_emergency_contact, parent, false);
            return new ContactViewHolder(view, listener, databaseHelper, this, contacts);
        }

        @Override
        public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
            EmergencyContact contact = contacts.get(position);
            holder.bind(contact);
        }

        @Override
        public int getItemCount() {
            return contacts.size();
        }
        
        public void removeItem(int position) {
            if (position >= 0 && position < contacts.size()) {
                contacts.remove(position);
                notifyItemRemoved(position);
            }
        }
        
        public void updateItem(int position, EmergencyContact contact) {
            if (position >= 0 && position < contacts.size()) {
                contacts.set(position, contact);
                notifyItemChanged(position);
            }
        }

        static class ContactViewHolder extends RecyclerView.ViewHolder {
            private final android.widget.TextView nameTextView, phoneTextView;
            private final android.widget.ImageButton editButton;
            private final android.widget.ImageView deleteIcon;
            private final ContactsFragment.OnContactClickListener listener;
            private final DatabaseHelper databaseHelper;
            private final ContactAdapter adapter;
            private final List<EmergencyContact> contacts;

            ContactViewHolder(@NonNull View itemView, ContactsFragment.OnContactClickListener listener, DatabaseHelper databaseHelper, ContactAdapter adapter, List<EmergencyContact> contacts) {
                super(itemView);
                nameTextView = itemView.findViewById(R.id.nameTextView);
                phoneTextView = itemView.findViewById(R.id.phoneTextView);
                editButton = itemView.findViewById(R.id.editButton);
                deleteIcon = itemView.findViewById(R.id.deleteIcon);
                this.listener = listener;
                this.databaseHelper = databaseHelper;
                this.adapter = adapter;
                this.contacts = contacts;
                
                // Make delete icon visible
                deleteIcon.setVisibility(android.view.View.VISIBLE);
                
                // Set click listeners
                editButton.setOnClickListener(v -> {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        EmergencyContact contact = contacts.get(position);
                        showEditContactDialog(contact, position);
                    }
                });
                
                deleteIcon.setOnClickListener(v -> {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        EmergencyContact contact = contacts.get(position);
                        showDeleteConfirmationDialog(contact, position);
                    }
                });
            }

            void bind(EmergencyContact contact) {
                nameTextView.setText(contact.getName());
                phoneTextView.setText(contact.getPhoneNumber() + " (" + contact.getRelationship() + ")");
                // Set regular item click for call/SMS options
                itemView.setOnClickListener(v -> listener.onContactClick(contact));
            }
            
            private void showEditContactDialog(EmergencyContact contact, int position) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(itemView.getContext());
                android.view.LayoutInflater inflater = android.view.LayoutInflater.from(itemView.getContext());
                android.view.View dialogView = inflater.inflate(R.layout.dialog_add_edit_contact, null);
                builder.setView(dialogView);

                android.widget.EditText nameEditText = dialogView.findViewById(R.id.nameEditText);
                android.widget.EditText phoneEditText = dialogView.findViewById(R.id.phoneEditText);
                android.widget.EditText relationEditText = dialogView.findViewById(R.id.relationEditText);
                android.widget.Button saveButton = dialogView.findViewById(R.id.saveButton);

                nameEditText.setText(contact.getName());
                phoneEditText.setText(contact.getPhoneNumber());
                relationEditText.setText(contact.getRelationship());

                android.app.AlertDialog dialog = builder.create();

                saveButton.setOnClickListener(v -> {
                    String name = nameEditText.getText().toString().trim();
                    String phone = phoneEditText.getText().toString().trim();
                    String relation = relationEditText.getText().toString().trim();

                    if (android.text.TextUtils.isEmpty(name) || android.text.TextUtils.isEmpty(phone)) {
                        android.widget.Toast.makeText(itemView.getContext(), "Name and phone number are required", android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Update contact
                    contact.setName(name);
                    contact.setPhoneNumber(phone);
                    contact.setRelationship(relation);
                    
                    databaseHelper.updateContact(contact);
                    
                    // Update UI
                    adapter.updateItem(position, contact);
                    dialog.dismiss();
                });

                dialog.show();
            }
            
            private void showDeleteConfirmationDialog(EmergencyContact contact, int position) {
                new android.app.AlertDialog.Builder(itemView.getContext())
                        .setTitle("Delete Contact")
                        .setMessage("Are you sure you want to delete " + contact.getName() + "?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            // Delete from database
                            databaseHelper.deleteContact(contact.getId());
                            
                            // Update UI
                            adapter.removeItem(position);
                            
                            android.widget.Toast.makeText(itemView.getContext(), "Contact deleted", android.widget.Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        }
    }
    
    interface OnContactClickListener {
        void onContactClick(EmergencyContact contact);
    }
}