package com.example.sosmate.models;

public class EmergencyContact {

    private int id;
    private String name;
    private String phoneNumber;
    private String relationship;
    private int priority;

    // ✅ Required empty constructor (for Firebase or serialization)
    public EmergencyContact() {}

    // ✅ Parameterized constructor
    public EmergencyContact(String name, String phoneNumber, String relationship, int id) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.relationship = relationship;
        this.id = id;
    }

    // ✅ Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getRelationship() {
        return relationship;
    }

    public String getRelation() {
        return relationship;
    }

    public int getPriority() {
        return priority;
    }

    // ✅ Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return name + " (" + relationship + ") - " + phoneNumber;
    }
}