package com.example.sosmate.fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.sosmate.R;
import com.example.sosmate.activities.LoginActivity;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.switchmaterial.SwitchMaterial;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsFragment extends Fragment {

    private static final String PREF_NAME = "SOSMatePrefs";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_NAME = "userName";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        initializeViews(view);
        setupUserDetails(view);
        setupClickListeners(view);

        return view;
    }

    private void initializeViews(View view) {
        // Views are initialized in the layout
    }

    private void setupUserDetails(View view) {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(PREF_NAME, 0);
        String userEmail = sharedPreferences.getString(KEY_USER_EMAIL, "user@sosmate.com");
        String userName = sharedPreferences.getString(KEY_USER_NAME, "User");

        TextView tvUsername = view.findViewById(R.id.tv_username);
        TextView tvUserEmail = view.findViewById(R.id.tv_useremail);

        if (tvUsername != null) {
            tvUsername.setText(userName);
        }
        if (tvUserEmail != null) {
            tvUserEmail.setText(userEmail);
        }
    }
    private void setupClickListeners(View view) {
        MaterialCardView logoutCard = view.findViewById(R.id.card_logout);
        if (logoutCard != null) {
            logoutCard.setOnClickListener(v -> confirmLogout());
        }

        SwitchMaterial darkModeSwitch = view.findViewById(R.id.switch_dark_mode);
        if (darkModeSwitch != null) {
            SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(PREF_NAME, 0);
            darkModeSwitch.setChecked(sharedPreferences.getBoolean("dark_mode", false));
            darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("dark_mode", isChecked);
                editor.apply();

                if (isChecked) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
                requireActivity().recreate();
            });
        }
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (dialog, which) -> performLogout())
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void performLogout() {
        // Clear user preferences
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(PREF_NAME, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // Navigate to login activity
        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        
        // Finish the current activity
        requireActivity().finish();

        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}