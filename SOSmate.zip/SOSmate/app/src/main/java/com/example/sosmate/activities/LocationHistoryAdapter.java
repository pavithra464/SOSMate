package com.example.sosmate.activities; // or adapters if you prefer

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sosmate.R;
import com.example.sosmate.models.LocationRecord;

import java.util.List;

public class LocationHistoryAdapter extends RecyclerView.Adapter<LocationHistoryAdapter.ViewHolder> {

    private final List<LocationRecord> locationList;

    public LocationHistoryAdapter(List<LocationRecord> locationList) {
        this.locationList = locationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_location, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LocationRecord record = locationList.get(position);
        holder.latitudeText.setText("Latitude: " + record.getLatitude());
        holder.longitudeText.setText("Longitude: " + record.getLongitude());
        
        // Format the timestamp to be more readable
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.getDefault());
        String formattedTime = sdf.format(new java.util.Date(record.getTimestamp()));
        holder.timestampText.setText("Time: " + formattedTime);
    }

    @Override
    public int getItemCount() {
        return locationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView latitudeText, longitudeText, timestampText;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            latitudeText = itemView.findViewById(R.id.latitudeText);
            longitudeText = itemView.findViewById(R.id.longitudeText);
            timestampText = itemView.findViewById(R.id.timestampText);
        }
    }
}