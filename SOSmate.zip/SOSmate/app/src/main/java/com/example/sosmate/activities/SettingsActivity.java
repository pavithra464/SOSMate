package com.example.sosmate.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sosmate.R;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}