package com.example.sosmate.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.sosmate.models.EmergencyContact;
import com.example.sosmate.models.LocationRecord;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sosmate.db";
    private static final int DATABASE_VERSION = 4; // incremented version for schema upgrade
    private static DatabaseHelper instance;

    // Emergency contacts table
    private static final String TABLE_CONTACTS = "emergency_contacts";
    private static final String COLUMN_CONTACT_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_CONTACT_PHONE = "phone";
    private static final String COLUMN_RELATION = "relation";

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_USER_PHONE = "phone";
    private static final String COLUMN_PASSWORD = "password";

    // Locations table
    private static final String TABLE_LOCATIONS = "locations";
    private static final String COLUMN_LOCATION_ID = "id";
    private static final String COLUMN_LATITUDE = "latitude";
    private static final String COLUMN_LONGITUDE = "longitude";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    private DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createContactsTable = "CREATE TABLE " + TABLE_CONTACTS + " (" +
                COLUMN_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_CONTACT_PHONE + " TEXT, " +
                COLUMN_RELATION + " TEXT)";
        db.execSQL(createContactsTable);

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT NOT NULL, " +
                COLUMN_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COLUMN_USER_PHONE + " TEXT, " +
                COLUMN_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsersTable);

        String createLocationsTable = "CREATE TABLE " + TABLE_LOCATIONS + " (" +
                COLUMN_LOCATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_LATITUDE + " REAL, " +
                COLUMN_LONGITUDE + " REAL, " +
                COLUMN_TIMESTAMP + " INTEGER)";
        db.execSQL(createLocationsTable);

        // Optional: add a demo user for testing
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, "Test User");
        values.put(COLUMN_EMAIL, "user@sosmate.com");
        values.put(COLUMN_PASSWORD, "password123");
        db.insert(TABLE_USERS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            String createUsersTable = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER_NAME + " TEXT NOT NULL, " +
                    COLUMN_EMAIL + " TEXT UNIQUE NOT NULL, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL)";
            db.execSQL(createUsersTable);
        }

        if (oldVersion < 3) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_USER_PHONE + " TEXT");
            } catch (Exception e) {
                // Ignore if column already exists
            }
        }

        if (oldVersion < 4) {
            String createLocationsTable = "CREATE TABLE IF NOT EXISTS " + TABLE_LOCATIONS + " (" +
                    COLUMN_LOCATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_LATITUDE + " REAL, " +
                    COLUMN_LONGITUDE + " REAL, " +
                    COLUMN_TIMESTAMP + " INTEGER)";
            db.execSQL(createLocationsTable);

            String createContactsTable = "CREATE TABLE IF NOT EXISTS " + TABLE_CONTACTS + " (" +
                    COLUMN_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_CONTACT_PHONE + " TEXT, " +
                    COLUMN_RELATION + " TEXT)";
            db.execSQL(createContactsTable);
        }
    }

    // -------- Emergency Contacts --------
    public void addContact(EmergencyContact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, contact.getName());
        values.put(COLUMN_CONTACT_PHONE, contact.getPhoneNumber());
        values.put(COLUMN_RELATION, contact.getRelation());
        db.insert(TABLE_CONTACTS, null, values);
        // Do not close db - let the SQLiteOpenHelper manage the connection
    }

    public List<EmergencyContact> getAllContacts() {
        List<EmergencyContact> contacts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CONTACTS, null);

        if (cursor.moveToFirst()) {
            do {
                EmergencyContact contact = new EmergencyContact(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTACT_PHONE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_RELATION)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CONTACT_ID))
                );
                contacts.add(contact);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // Do not close db - let the SQLiteOpenHelper manage the connection
        return contacts;
    }

    public void deleteContact(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, COLUMN_CONTACT_ID + "=?", new String[]{String.valueOf(id)});
        // Do not close db - let the SQLiteOpenHelper manage the connection
    }

    public void updateContact(EmergencyContact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, contact.getName());
        values.put(COLUMN_CONTACT_PHONE, contact.getPhoneNumber());
        values.put(COLUMN_RELATION, contact.getRelation());
        db.update(TABLE_CONTACTS, values, COLUMN_CONTACT_ID + " = ?", new String[]{String.valueOf(contact.getId())});
    }

    // -------- User Management --------
    public boolean addUser(String name, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_USER_PHONE, phone);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        // Do not close db - let the SQLiteOpenHelper manage the connection
        return result != -1;
    }

    public boolean validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                        COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{email, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        // Do not close db - let the SQLiteOpenHelper manage the connection
        return exists;
    }

    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + "=?",
                new String[]{email});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        // Do not close db - let the SQLiteOpenHelper manage the connection
        return exists;
    }

    public String getUserName() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_NAME + " FROM " + TABLE_USERS, null);
        String userName = "User"; // Default value
        if (cursor.moveToFirst()) {
            userName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME));
        }
        cursor.close();
        return userName;
    }

    public void insertLocation(double latitude, double longitude, String timestamp) {
        // Convert string timestamp to long for database storage
        long longTimestamp = 0;
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault());
            java.util.Date date = sdf.parse(timestamp);
            longTimestamp = date.getTime();
        } catch (Exception e) {
            longTimestamp = System.currentTimeMillis();
        }
        
        insertLocationWithTimestamp(latitude, longitude, longTimestamp);
    }
    
    public void insertLocationWithTimestamp(double latitude, double longitude, long timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_TIMESTAMP, timestamp);
        db.insert(TABLE_LOCATIONS, null, values);
        // Do not close db - let the SQLiteOpenHelper manage the connection
    }

    public List<LocationRecord> getAllLocations() {
        List<LocationRecord> locations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_LOCATIONS + " ORDER BY " + COLUMN_TIMESTAMP + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                double latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_LATITUDE));
                double longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_LONGITUDE));
                long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));
                locations.add(new LocationRecord(latitude, longitude, timestamp));
            } while (cursor.moveToNext());
        }
        cursor.close();
        // Do not close db - let the SQLiteOpenHelper manage the connection
        return locations;
    }
}