package com.example.sosmate.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sosmate.R;
import com.example.sosmate.database.DatabaseHelper;
import com.example.sosmate.models.EmergencyContact;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class EmergencyContactsActivity extends AppCompatActivity implements EmergencyContactsAdapter.OnContactListener {

    private DatabaseHelper databaseHelper;
    private EmergencyContactsAdapter adapter;
    private List<EmergencyContact> contacts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);

        databaseHelper = DatabaseHelper.getInstance(this);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EmergencyContactsAdapter(contacts, this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> showAddEditContactDialog(null));

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                EmergencyContact contact = adapter.getContactAt(position);
                databaseHelper.deleteContact(contact.getId());
                loadContacts();
                Toast.makeText(EmergencyContactsActivity.this, "Contact deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        loadContacts();
    }

    private void loadContacts() {
        contacts.clear();
        contacts.addAll(databaseHelper.getAllContacts());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onContactClick(int position) {
        EmergencyContact contact = adapter.getContactAt(position);
        showAddEditContactDialog(contact);
    }

    private void showAddEditContactDialog(final EmergencyContact contact) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_edit_contact, null);
        builder.setView(dialogView);

        final EditText nameEditText = dialogView.findViewById(R.id.nameEditText);
        final EditText phoneEditText = dialogView.findViewById(R.id.phoneEditText);
        final EditText relationEditText = dialogView.findViewById(R.id.relationEditText);
        Button saveButton = dialogView.findViewById(R.id.saveButton);

        if (contact != null) {
            nameEditText.setText(contact.getName());
            phoneEditText.setText(contact.getPhoneNumber());
            relationEditText.setText(contact.getRelation());
        }

        final AlertDialog dialog = builder.create();

        saveButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString().trim();
            String phone = phoneEditText.getText().toString().trim();
            String relation = relationEditText.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone)) {
                Toast.makeText(EmergencyContactsActivity.this, "Name and phone number are required", Toast.LENGTH_SHORT).show();
                return;
            }

            if (contact == null) { // Add new contact
                databaseHelper.addContact(new EmergencyContact(name, phone, relation, 0));
            } else { // Update existing contact
                contact.setName(name);
                contact.setPhoneNumber(phone);
                contact.setRelationship(relation);
                databaseHelper.updateContact(contact);
            }

            loadContacts();
            dialog.dismiss();
        });

        dialog.show();
    }
}
