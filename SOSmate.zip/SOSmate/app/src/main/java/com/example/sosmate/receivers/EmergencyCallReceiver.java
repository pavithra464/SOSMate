package com.example.sosmate.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

public class EmergencyCallReceiver extends BroadcastReceiver {

    private static final String TAG = "EmergencyCallReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        Log.d(TAG, "Phone state changed: " + state);
        // TODO: Detect emergency call state changes here
    }
}