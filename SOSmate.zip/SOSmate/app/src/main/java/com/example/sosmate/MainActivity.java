package com.example.sosmate;
import com.example.sosmate.models.EmergencyContact;
import com.example.sosmate.models.LocationRecord;
import com.example.sosmate.fragments.ContactsFragment;
import com.example.sosmate.fragments.HomeFragment;
import com.example.sosmate.fragments.LocationFragment;
import com.example.sosmate.fragments.SafetyFragment;
import com.example.sosmate.fragments.SettingsFragment;
import com.example.sosmate.activities.AboutUsActivity;

import com.example.sosmate.database.DatabaseHelper;

import android.content.SharedPreferences;
import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int POWER_BUTTON_CLICKS = 3;
    private static final long POWER_BUTTON_TIMEOUT = 2000; // 2 seconds

    // UI Components
    private TextView statusText;
    private TextView locationText;
    private TextView checkinTimeText;
    private TextView userGreetingText;
    private TextView locationStatusText;
    private TextView contactsStatusText;
    private com.google.android.material.card.MaterialCardView emergencySosCard;
    private com.google.android.material.card.MaterialCardView panicAlertCard;
    private com.google.android.material.card.MaterialCardView fakeCallCard;
    private com.google.android.material.card.MaterialCardView shareLocationCard;
    private com.google.android.material.card.MaterialCardView safetyCheckinCard;
    private com.google.android.material.card.MaterialCardView aboutUsCard;
    private BottomNavigationView bottomNavigation;

    // Core functionality
    private LocationManager locationManager;
    private SpeechRecognizer speechRecognizer;
    private MediaPlayer alarmPlayer;
    private Vibrator vibrator;
    private boolean isProtected = false;
    private boolean isLocationActive = false;
    private boolean voiceActivationEnabled = true;

    // Emergency contacts
    private List<EmergencyContact> emergencyContacts;
    private Location currentLocation;

    // Database helper
    private DatabaseHelper databaseHelper;

    // Power button tracking
    private int powerButtonClickCount = 0;
    private long lastPowerButtonTime = 0;
    private Handler powerButtonHandler = new Handler();
    
    // SharedPreferences for user data
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "SOSMatePrefs";
    private static final String KEY_USER_NAME = "userName";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database first to avoid null pointer exceptions
        databaseHelper = DatabaseHelper.getInstance(this);
        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        
        initializeViews();
        initializeServices();
        setupEmergencyContacts();
        checkPermissions();
        updateUI();
    }

    private void initializeViews() {
        statusText = findViewById(R.id.statusText);
        locationText = findViewById(R.id.locationText);
        checkinTimeText = findViewById(R.id.checkinTimeText);
        userGreetingText = findViewById(R.id.userGreetingText);
        locationStatusText = findViewById(R.id.locationStatusText);
        contactsStatusText = findViewById(R.id.contactsStatusText);
        emergencySosCard = findViewById(R.id.emergencySosCard);
        panicAlertCard = findViewById(R.id.panicAlertCard);
        fakeCallCard = findViewById(R.id.fakeCallCard);
        shareLocationCard = findViewById(R.id.shareLocationCard);
        safetyCheckinCard = findViewById(R.id.safetyCheckinCard);
        aboutUsCard = findViewById(R.id.aboutUsCard);
        bottomNavigation = findViewById(R.id.bottomNavigation);

        // Set card click listeners
        emergencySosCard.setOnClickListener(v -> triggerEmergencySOS());
        panicAlertCard.setOnClickListener(v -> triggerPanicAlert());
        fakeCallCard.setOnClickListener(v -> initiateDiscreteExit());
        shareLocationCard.setOnClickListener(v -> shareCurrentLocation());
        safetyCheckinCard.setOnClickListener(v -> performSafetyCheckin());
        aboutUsCard.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutUsActivity.class);
            startActivity(intent);
        });

        setupBottomNavigation();
    }

    private void initializeServices() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        // Initialize speech recognizer
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new VoiceRecognitionListener());
        }
    }

    private void setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                // Show main content instead of fragment
                findViewById(R.id.mainContent).setVisibility(View.VISIBLE);
                findViewById(R.id.fragmentContainer).setVisibility(View.GONE);
                updateUI();
                return true;
            } else if (itemId == R.id.nav_location) {
                selectedFragment = new LocationFragment();
            } else if (itemId == R.id.nav_contacts) {
                selectedFragment = new ContactsFragment();
            } else if (itemId == R.id.nav_safety) {
                selectedFragment = new SafetyFragment();
            } else if (itemId == R.id.nav_settings) {
                selectedFragment = new SettingsFragment();
            }

            if (selectedFragment != null) {
                // Hide main content and show fragment container
                findViewById(R.id.mainContent).setVisibility(View.GONE);
                findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);

                // Replace fragment
                getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainer, selectedFragment)
                    .commit();
                return true;
            }

            return false;
        });
    }

    private void setupEmergencyContacts() {
        emergencyContacts = databaseHelper.getAllContacts();
    }

    private void checkPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.SEND_SMS);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CALL_PHONE);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.RECORD_AUDIO);
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissionsNeeded.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
        } else {
            startLocationUpdates();
            startVoiceRecognition();
            isProtected = true;
            updateUI();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                startLocationUpdates();
                startVoiceRecognition();
                isProtected = true;
            } else {
                showPermissionDeniedDialog();
            }
            updateUI();
        }
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    10000, 10, this);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                    10000, 10, this);
            isLocationActive = true;
        }
    }

    private void startVoiceRecognition() {
        if (voiceActivationEnabled && speechRecognizer != null &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            speechRecognizer.startListening(intent);
        }
    }

    public void triggerEmergencySOS() {
        isProtected = true;

        // Save current location to database with current timestamp
        if (currentLocation != null) {
            long timestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), timestamp);
            Toast.makeText(this, "Emergency location saved!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Unable to save location: not available.", Toast.LENGTH_SHORT).show();
        }

        // Send emergency messages
        sendEmergencyMessages();

        // Start location sharing
        shareCurrentLocation();

        // Vibrate and sound alarm
        triggerAlarmAndVibration();

        // Show confirmation
        showEmergencyTriggeredDialog();

        updateUI();
    }

    public void triggerPanicAlert() {
        // Sound alarm and flash
        triggerAlarmAndVibration();

        // Send panic messages
        sendPanicMessages();

        Toast.makeText(this, "Panic Alert Activated!", Toast.LENGTH_SHORT).show();
    }

    public void initiateDiscreteExit() {
        // Simulate incoming call
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:+911234567890")); // Fake number

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED) {
            startActivity(intent);
        }

        Toast.makeText(this, "Discrete Exit Initiated", Toast.LENGTH_SHORT).show();
    }

    public void shareCurrentLocation() {
        if (currentLocation != null) {
            String locationMessage = String.format(Locale.getDefault(),
                    "My current location: https://maps.google.com/?q=%f,%f\nLat: %f, Long: %f",
                    currentLocation.getLatitude(), currentLocation.getLongitude(),
                    currentLocation.getLatitude(), currentLocation.getLongitude());

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, locationMessage);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My Location - SOSMate");
            startActivity(Intent.createChooser(shareIntent, "Share Location"));

            // Also send to emergency contacts
            sendLocationToContacts();
        } else {
            Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show();
        }
    }

    public void performSafetyCheckin() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String timestamp = sdf.format(new Date());

        String checkinMessage = String.format(
                "Safety Check-in: I'm safe and well at %s. Current location: %s",
                timestamp,
                currentLocation != null ?
                        String.format(Locale.getDefault(), "Lat: %.4f, Long: %.4f",
                                currentLocation.getLatitude(), currentLocation.getLongitude()) :
                        "Location unavailable"
        );

        // Save current location to database for check-in
        if (currentLocation != null) {
            long longTimestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), longTimestamp);
            Toast.makeText(this, "Safety check-in location saved!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Unable to save location: not available.", Toast.LENGTH_SHORT).show();
        }

        // Send to all emergency contacts
        for (EmergencyContact contact : emergencyContacts) {
            sendSMS(contact.getPhoneNumber(), checkinMessage);
        }

        // Update UI to show the check-in time using the long timestamp for consistency
        updateCheckinDisplayFromDatabase();
        
        Toast.makeText(this, "Safety check-in sent!", Toast.LENGTH_SHORT).show();
    }
    
    private void updateCheckinTimeDisplay(String timestamp) {
        if (checkinTimeText != null) {
            checkinTimeText.setText(formatTimeForDisplay(timestamp));
        }
    }
    
    private String formatTimeForDisplay(String timestamp) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date date = inputFormat.parse(timestamp);
            
            // Format to show time like "2h Ago" or "Just now"
            long currentTime = System.currentTimeMillis();
            long eventTime = date.getTime();
            long diff = currentTime - eventTime;
            
            long seconds = diff / 1000;
            long minutes = seconds / 60;
            long hours = minutes / 60;
            long days = hours / 24;
            
            if (seconds < 60) {
                return "Just now";
            } else if (minutes < 60) {
                return minutes + "m ago";
            } else if (hours < 24) {
                return hours + "h ago";
            } else {
                return days + "d ago";
            }
        } catch (Exception e) {
            // If parsing fails, return the original timestamp
            return timestamp.split(" ")[1]; // Just show the time part
        }
    }
    
    private void updateCheckinDisplayFromDatabase() {
        if (checkinTimeText != null) {
            try {
                // Get the most recent location record from the database
                List<LocationRecord> locations = databaseHelper.getAllLocations();
                if (locations != null && !locations.isEmpty()) {
                    // The most recent location will be the first one since we order by timestamp DESC
                    LocationRecord latestLocation = locations.get(0);
                    
                    // Format the timestamp for display
                    Date date = new Date(latestLocation.getTimestamp());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    String formattedDateTime = sdf.format(date);
                    
                    checkinTimeText.setText(formatTimeForDisplay(formattedDateTime));
                } else {
                    checkinTimeText.setText("Never");
                }
            } catch (Exception e) {
                checkinTimeText.setText("Error");
                // Log the error or handle it as needed
                e.printStackTrace();
            }
        }
    }

    private void sendEmergencyMessages() {
        String emergencyMessage = createEmergencyMessage();

        for (EmergencyContact contact : emergencyContacts) {
            sendSMS(contact.getPhoneNumber(), emergencyMessage);
        }
    }

    private void sendPanicMessages() {
        String panicMessage = "PANIC ALERT! I need immediate help. This is an automated message from SOSMate.";

        for (EmergencyContact contact : emergencyContacts) {
            sendSMS(contact.getPhoneNumber(), panicMessage);
        }
    }

    private void sendLocationToContacts() {
        if (currentLocation == null) return;

        String locationMessage = String.format(Locale.getDefault(),
                "Location Update: I'm at https://maps.google.com/?q=%f,%f (Lat: %f, Long: %f)",
                currentLocation.getLatitude(), currentLocation.getLongitude(),
                currentLocation.getLatitude(), currentLocation.getLongitude());

        for (EmergencyContact contact : emergencyContacts) {
            sendSMS(contact.getPhoneNumber(), locationMessage);
        }
    }

    private String createEmergencyMessage() {
        StringBuilder message = new StringBuilder("EMERGENCY SOS ALERT!\n\n");
        message.append("This is an automated emergency message from SOSMate.\n");
        message.append("I need immediate help!\n\n");

        if (currentLocation != null) {
            message.append(String.format(Locale.getDefault(),
                    "My location: https://maps.google.com/?q=%f,%f\n",
                    currentLocation.getLatitude(), currentLocation.getLongitude()));
            message.append(String.format(Locale.getDefault(),
                    "Coordinates: Lat: %f, Long: %f\n",
                    currentLocation.getLatitude(), currentLocation.getLongitude()));
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        message.append("Time: ").append(sdf.format(new Date()));

        return message.toString();
    }

    private void sendSMS(String phoneNumber, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                // Split long messages
                ArrayList<String> parts = smsManager.divideMessage(message);
                smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to send SMS to " + phoneNumber, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void triggerAlarmAndVibration() {
        // Vibration pattern: wait 0ms, vibrate 500ms, wait 200ms, vibrate 500ms
        if (vibrator != null && vibrator.hasVibrator()) {
            long[] pattern = {0, 500, 200, 500, 200, 500};
            vibrator.vibrate(pattern, -1);
        }

        // Play alarm sound
        try {
            if (alarmPlayer != null) {
                alarmPlayer.release();
            }
            alarmPlayer = MediaPlayer.create(this, Settings.System.DEFAULT_ALARM_ALERT_URI);
            if (alarmPlayer != null) {
                alarmPlayer.setLooping(true);
                alarmPlayer.start();

                // Stop alarm after 10 seconds
                new Handler().postDelayed(() -> {
                    if (alarmPlayer != null && alarmPlayer.isPlaying()) {
                        alarmPlayer.stop();
                        alarmPlayer.release();
                        alarmPlayer = null;
                    }
                }, 10000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateUI() {
        // Update username
        if (userGreetingText != null) {
            String userName = sharedPreferences.getString(KEY_USER_NAME, "User"); // Default to "User" if not found
            userGreetingText.setText("Hello, " + userName + "!");
        }

        // Update location status
        if (locationStatusText != null) {
            List<LocationRecord> locations = databaseHelper.getAllLocations();
            if (locations != null && !locations.isEmpty()) {
                locationStatusText.setText("Active");
            } else {
                locationStatusText.setText("Inactive");
            }
        }

        // Update contacts status
        if (contactsStatusText != null) {
            List<EmergencyContact> contacts = databaseHelper.getAllContacts();
            contactsStatusText.setText(contacts.size() + " Ready");
        }

        // Update status
        if (statusText != null) {
            if (isProtected) {
                statusText.setText("System status: All services active");
            } else {
                statusText.setText("System status: Setup required");
            }
        }

        // Update location display
        if (locationText != null) {
            if (currentLocation != null) {
                locationText.setText(String.format(Locale.getDefault(),
                        "Lat: %.4f, Long: %.4f",
                        currentLocation.getLatitude(), currentLocation.getLongitude()));
            } else {
                locationText.setText("Location: Fetching...");
            }
        }
        
        // Update check-in time display
        updateCheckinDisplayFromDatabase();
    }

    // Power button SOS implementation
    @Override
    protected void onResume() {
        super.onResume();
        // Reset power button counter when app becomes active
        powerButtonClickCount = 0;
        lastPowerButtonTime = 0;
    }

    // Simulate power button detection (in real implementation, this would be handled by a service)
    public void onPowerButtonPressed() {
        long currentTime = System.currentTimeMillis();

        if (currentTime - lastPowerButtonTime > POWER_BUTTON_TIMEOUT) {
            powerButtonClickCount = 1;
        } else {
            powerButtonClickCount++;
        }

        lastPowerButtonTime = currentTime;

        if (powerButtonClickCount >= POWER_BUTTON_CLICKS) {
            triggerEmergencySOS();
            powerButtonClickCount = 0;
        }

        // Reset counter after timeout
        powerButtonHandler.removeCallbacksAndMessages(null);
        powerButtonHandler.postDelayed(() -> powerButtonClickCount = 0, POWER_BUTTON_TIMEOUT);
    }

    // Location listener implementation
    @Override
    public void onLocationChanged(@NonNull Location location) {
        currentLocation = location;
        updateUI();
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {}

    @Override
    public void onProviderDisabled(@NonNull String provider) {}

    // Voice recognition listener
    private class VoiceRecognitionListener implements RecognitionListener {
        @Override
        public void onResults(Bundle results) {
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (matches != null) {
                for (String result : matches) {
                    if (result.toLowerCase().contains("help me") ||
                            result.toLowerCase().contains("emergency") ||
                            result.toLowerCase().contains("sos")) {
                        triggerEmergencySOS();
                        break;
                    }
                }
            }
            // Restart listening
            if (voiceActivationEnabled) {
                startVoiceRecognition();
            }
        }

        @Override
        public void onError(int error) {
            // Restart listening on error
            if (voiceActivationEnabled) {
                new Handler().postDelayed(() -> startVoiceRecognition(), 1000);
            }
        }

        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}
    }

    private void showPermissionDeniedDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permissions Required")
                .setMessage("SOSMate requires location, SMS, phone, and microphone permissions to function properly. Please grant all permissions for your safety.")
                .setPositiveButton("Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showEmergencyTriggeredDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Emergency SOS Activated")
                .setMessage("Emergency messages have been sent to your contacts. Help is on the way!")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .setCancelable(false)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }

        if (alarmPlayer != null) {
            alarmPlayer.release();
        }

        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }

        powerButtonHandler.removeCallbacksAndMessages(null);
    }
    
    // Method to refresh UI when needed (e.g., after login/logout)
    public void refreshUI() {
        runOnUiThread(this::updateUI);
    }

    // Getter methods for DashboardFragment
    public boolean isProtected() {
        return isProtected;
    }

    // Setter methods for safety features
    public void setSafetyStatus(boolean enabled) {
        isProtected = enabled;
        updateUI();
    }

    public boolean toggleSafetyStatus() {
        isProtected = !isProtected;
        updateUI();
        return isProtected;
    }

    public void setDiscreetMode(boolean enabled) {
        // In a complete implementation, this would control whether safety indicators are visible
        voiceActivationEnabled = !enabled; // Disable voice activation in discreet mode
        // Additional discreet mode functionality would go here
        updateUI();
    }

    public void setLocationSharingEnabled(boolean enabled) {
        // In a complete implementation, this would control location sharing behavior
        isLocationActive = enabled;
        updateUI();
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

}
