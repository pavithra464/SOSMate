package com.example.sosmate.fragments;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.sosmate.MainActivity;
import com.example.sosmate.R;
import com.example.sosmate.activities.EmergencyContactsActivity;
import com.example.sosmate.activities.EmergencyTriggerActivity;
import com.example.sosmate.activities.LocationHistoryActivity;
import com.example.sosmate.database.DatabaseHelper;
import com.google.android.material.card.MaterialCardView;

public class HomeFragment extends Fragment {

    private MaterialCardView emergencyCard;
    private MaterialCardView panicAlertCard;
    private MaterialCardView shareLocationCard;
    private MaterialCardView safetyCheckinCard;
    
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize database helper
        databaseHelper = DatabaseHelper.getInstance(requireContext());

        // Bind the cards
        emergencyCard = view.findViewById(R.id.card_emergency_sos);
        panicAlertCard = view.findViewById(R.id.card_panic_alert);
        shareLocationCard = view.findViewById(R.id.card_share_location);
        safetyCheckinCard = view.findViewById(R.id.card_safety_checkin);

        // Set click listeners
        emergencyCard.setOnClickListener(v -> triggerEmergencySOS());
        panicAlertCard.setOnClickListener(v -> triggerPanicAlert());
        shareLocationCard.setOnClickListener(v -> shareCurrentLocation());
        safetyCheckinCard.setOnClickListener(v -> performSafetyCheckin());

        return view;
    }

    private void triggerEmergencySOS() {
        // Save current location to database with current timestamp
        Location currentLocation = getCurrentLocationFromActivity();
        
        if (currentLocation != null) {
            long timestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), timestamp);
            Toast.makeText(requireContext(), "Location saved for SOS event!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(requireContext(), "Location unavailable for SOS event.", Toast.LENGTH_SHORT).show();
        }
        
        // Navigate to emergency trigger activity
        Intent intent = new Intent(requireContext(), EmergencyTriggerActivity.class);
        intent.putExtra("emergency_type", "SOS");
        startActivity(intent);
        Toast.makeText(requireContext(), "Emergency SOS activated", Toast.LENGTH_SHORT).show();
    }
    
    private Location getCurrentLocationFromActivity() {
        if (requireActivity() != null && requireActivity() instanceof MainActivity) {
            MainActivity mainActivity = (MainActivity) requireActivity();
            return mainActivity.getCurrentLocation();
        }
        return null;
    }

    private void triggerPanicAlert() {
        // Save current location to database with current timestamp
        Location currentLocation = getCurrentLocationFromActivity();
        
        if (currentLocation != null) {
            long timestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), timestamp);
            Toast.makeText(requireContext(), "Location saved for panic event!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(requireContext(), "Location unavailable for panic event.", Toast.LENGTH_SHORT).show();
        }
        
        // Navigate to emergency trigger activity
        Intent intent = new Intent(requireContext(), EmergencyTriggerActivity.class);
        intent.putExtra("emergency_type", "PANIC");
        startActivity(intent);
        Toast.makeText(requireContext(), "Panic Alert activated", Toast.LENGTH_SHORT).show();
    }



    private void shareCurrentLocation() {
        // Save current location to database with current timestamp
        Location currentLocation = getCurrentLocationFromActivity();
        
        if (currentLocation != null) {
            long timestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), timestamp);
            Toast.makeText(requireContext(), "Location saved for sharing!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(requireContext(), "Location unavailable for sharing.", Toast.LENGTH_SHORT).show();
        }
        
        // Navigate to location history activity to share current location
        Intent intent = new Intent(requireContext(), LocationHistoryActivity.class);
        startActivity(intent);
        Toast.makeText(requireContext(), "Sharing current location", Toast.LENGTH_SHORT).show();
    }

    private void performSafetyCheckin() {
        // Save current location to database with current timestamp
        Location currentLocation = getCurrentLocationFromActivity();
        
        if (currentLocation != null) {
            long timestamp = System.currentTimeMillis();
            databaseHelper.insertLocationWithTimestamp(currentLocation.getLatitude(), currentLocation.getLongitude(), timestamp);
            Toast.makeText(requireContext(), "Location saved for safety check-in!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(requireContext(), "Location unavailable for safety check-in.", Toast.LENGTH_SHORT).show();
        }
        
        // Navigate to contacts activity to perform safety check-in
        Intent intent = new Intent(requireContext(), EmergencyContactsActivity.class);
        startActivity(intent);
        Toast.makeText(requireContext(), "Safety check-in sent", Toast.LENGTH_SHORT).show();
    }
}
