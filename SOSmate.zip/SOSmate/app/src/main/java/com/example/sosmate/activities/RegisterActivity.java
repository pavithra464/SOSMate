package com.example.sosmate.activities;

import com.example.sosmate.MainActivity;
import com.example.sosmate.R;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import com.example.sosmate.database.DatabaseHelper;
import com.example.sosmate.models.User;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText nameEditText, emailEditText, phoneEditText, passwordEditText, confirmPasswordEditText;
    private TextInputLayout nameInputLayout, emailInputLayout, phoneInputLayout, passwordInputLayout, confirmPasswordInputLayout;
    private Button registerButton;
    private Button loginButton;
    private ProgressBar progressBar;

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "SOSMatePrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_PHONE = "userPhone";

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initializeViews();
        setupSharedPreferences();
        setupClickListeners();

        databaseHelper = DatabaseHelper.getInstance(this);
    }

    private void initializeViews() {
        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        nameInputLayout = findViewById(R.id.nameInputLayout);
        emailInputLayout = findViewById(R.id.emailInputLayout);
        phoneInputLayout = findViewById(R.id.phoneInputLayout);
        passwordInputLayout = findViewById(R.id.passwordInputLayout);
        confirmPasswordInputLayout = findViewById(R.id.confirmPasswordInputLayout);
        registerButton = findViewById(R.id.registerButton);
        loginButton = findViewById(R.id.loginButton);
        progressBar = findViewById(R.id.progressBar);
    }


    private void setupSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
    }

    private void setupClickListeners() {
        registerButton.setOnClickListener(v -> attemptRegistration());
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void attemptRegistration() {
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();

        // Clear previous errors
        clearErrors();

        // Validate input
        if (!validateInput(name, email, phone, password, confirmPassword)) {
            return;
        }

        // Show progress
        showProgress(true);

        if (registerUser(name, email, phone, password)) {
            saveUserData(name, email, phone);
            showProgress(false);
            showRegistrationSuccess();
        } else {
            showProgress(false);
            showRegistrationError();
        }
    }

    private void clearErrors() {
        nameInputLayout.setError(null);
        emailInputLayout.setError(null);
        phoneInputLayout.setError(null);
        passwordInputLayout.setError(null);
        confirmPasswordInputLayout.setError(null);
    }

    private boolean validateInput(String name, String email, String phone, String password, String confirmPassword) {
        boolean isValid = true;

        if (TextUtils.isEmpty(name)) {
            nameInputLayout.setError("Name is required");
            isValid = false;
        } else if (name.length() < 2) {
            nameInputLayout.setError("Name must be at least 2 characters");
            isValid = false;
        }

        if (TextUtils.isEmpty(email)) {
            emailInputLayout.setError("Email is required");
            isValid = false;
        } else if (!isValidEmail(email)) {
            emailInputLayout.setError("Please enter a valid email");
            isValid = false;
        }

        if (TextUtils.isEmpty(phone)) {
            phoneInputLayout.setError("Phone number is required");
            isValid = false;
        } else if (!isValidPhoneNumber(phone)) {
            phoneInputLayout.setError("Please enter a valid phone number");
            isValid = false;
        }

        if (TextUtils.isEmpty(password)) {
            passwordInputLayout.setError("Password is required");
            isValid = false;
        } else if (password.length() < 6) {
            passwordInputLayout.setError("Password must be at least 6 characters");
            isValid = false;
        } else if (!isValidPassword(password)) {
            passwordInputLayout.setError("Password must contain letters and numbers");
            isValid = false;
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            confirmPasswordInputLayout.setError("Please confirm your password");
            isValid = false;
        } else if (!password.equals(confirmPassword)) {
            confirmPasswordInputLayout.setError("Passwords do not match");
            isValid = false;
        }

        return isValid;
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isValidPhoneNumber(String phone) {
        // Remove any spaces, dashes, or parentheses
        String cleanPhone = phone.replaceAll("[\\s\\-\\(\\)]", "");
        return cleanPhone.length() >= 10 && cleanPhone.matches("\\d+");
    }

    private boolean isValidPassword(String password) {
        // Password must contain at least one letter and one number
        return password.matches(".*[a-zA-Z].*") && password.matches(".*\\d.*");
    }

    private boolean registerUser(String name, String email, String phone, String password) {
        // Check if email already exists in database
        if (databaseHelper.isEmailRegistered(email)) {
            emailInputLayout.setError("Email already exists");
            return false;
        }

        // Insert into database using the main DatabaseHelper
        boolean success = databaseHelper.addUser(name, email, phone, password);
        return success;
    }

    private void saveUserData(String name, String email, String phone) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHONE, phone);
        editor.apply();
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        registerButton.setEnabled(!show);
        nameEditText.setEnabled(!show);
        emailEditText.setEnabled(!show);
        phoneEditText.setEnabled(!show);
        passwordEditText.setEnabled(!show);
        confirmPasswordEditText.setEnabled(!show);
    }

    private void showRegistrationSuccess() {
        Toast.makeText(this, "Registration successful! Welcome to SOSMate!", Toast.LENGTH_LONG).show();

        // Navigate to dashboard
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showRegistrationError() {
        Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_LONG).show();
        emailInputLayout.setError("Registration failed. This email might already be in use.");
    }
}