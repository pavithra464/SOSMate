package com.example.sosmate.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.sosmate.MainActivity;
import com.example.sosmate.R;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SafetyFragment extends Fragment {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_safety, container, false);

        // Initialize all switches using helper
        initSwitch(view, R.id.switch_safety_status, true,
                isChecked -> {
                    MainActivity activity = (MainActivity) requireActivity();
                    activity.setSafetyStatus(isChecked);
                    showToast(isChecked ? "Safety features activated" : "Safety features deactivated");
                });
        initSwitch(view, R.id.switch_discreet_mode, false,
                isChecked -> {
                    MainActivity activity = (MainActivity) requireActivity();
                    activity.setDiscreetMode(isChecked);
                    showToast(isChecked ? "Discreet mode activated" : "Discreet mode deactivated");
                });
        initSwitch(view, R.id.switch_location_sharing, true,
                isChecked -> {
                    MainActivity activity = (MainActivity) requireActivity();
                    activity.setLocationSharingEnabled(isChecked);
                    showToast(isChecked ? "Location sharing activated" : "Location sharing deactivated");
                });

        return view;
    }

    private void initSwitch(View view, int switchId, boolean defaultState, SwitchChangeListener listener) {
        SwitchMaterial switchMaterial = view.findViewById(switchId);
        if (switchMaterial != null) {
            switchMaterial.setChecked(defaultState);
            if (listener != null) {
                switchMaterial.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onChanged(isChecked));
            }
        }
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private interface SwitchChangeListener {
        void onChanged(boolean isChecked);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ScrollView scrollView = view.findViewById(R.id.scrollView);
        if (scrollView != null) {
            scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
        }
    }
}