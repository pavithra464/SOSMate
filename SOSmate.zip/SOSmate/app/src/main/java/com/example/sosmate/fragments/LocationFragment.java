package com.example.sosmate.fragments;

import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.example.sosmate.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocationFragment extends Fragment implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;

    private TextView currentLocationText;
    private TextView coordinatesText;
    private TextView shareLocationStatus;
    private TextView autoCheckinStatus;
    private View viewLocationHistoryButton;
    private ProgressBar progressRefreshLocation;
    
    // Google Maps
    private MapView mapView;
    private GoogleMap googleMap;
    private boolean isMapReady = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_location, container, false);

        initializeViews(view);
        
        // Initialize MapView
        mapView = view.findViewById(R.id.map_view);
        if (mapView != null) {
            mapView.onCreate(savedInstanceState);
            mapView.getMapAsync(this);
        }
        
        // Set initial state to show that location is being fetched
        currentLocationText.setText("Fetching location...");
        coordinatesText.setText("Lat: --, Long: --");

        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        createLocationRequest();
        createLocationCallback();

        startLocationUpdates();

        setupClickListeners(view);

        return view;
    }

    private void initializeViews(View view) {
        currentLocationText = view.findViewById(R.id.tv_current_location);
        coordinatesText = view.findViewById(R.id.tv_coordinates);
        viewLocationHistoryButton = view.findViewById(R.id.btn_view_location_history);
        progressRefreshLocation = view.findViewById(R.id.progress_refresh_location);
        // Note: mapView is initialized separately in onCreateView
    }

    private void setupClickListeners(View view) {
        view.findViewById(R.id.btn_refresh_location).setOnClickListener(v -> refreshLocation());
        view.findViewById(R.id.btn_view_location_history).setOnClickListener(v -> openLocationHistory());
    }

    private void openLocationHistory() {
        // Start the Location History Activity
        Intent intent = new Intent(getActivity(), com.example.sosmate.activities.LocationHistoryActivity.class);
        startActivity(intent);
    }

    private void toggleShareLocation() {
        String currentText = shareLocationStatus.getText().toString();
        if (currentText.contains("✓")) {
            shareLocationStatus.setText("Share Location");
            shareLocationStatus.setTextColor(getResources().getColor(android.R.color.darker_gray, requireContext().getTheme()));
        } else {
            shareLocationStatus.setText("✓ Share Location");
            shareLocationStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark, requireContext().getTheme()));
        }
    }


    private void createLocationRequest() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000); // 10 seconds
        locationRequest.setFastestInterval(5000); // 5 seconds
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    private void createLocationCallback() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null || locationResult.getLocations().isEmpty()) {
                    // Instead of showing hardcoded location, show a message indicating location is unavailable
                    currentLocationText.setText("Location unavailable");
                    coordinatesText.setText("Lat: --, Long: --");
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        updateLocationUI(location);
                    }
                }
            }
        };
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(requireContext(),
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void refreshLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(requireContext(),
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }
        
        // Show visual feedback that refresh is happening
        currentLocationText.setText("Refreshing location...");
        coordinatesText.setText("Lat: --, Long: --");
        
        // Show progress indicator
        progressRefreshLocation.setVisibility(View.VISIBLE);
        // Disable button during refresh to prevent multiple taps
        View refreshButton = getView() != null ? getView().findViewById(R.id.btn_refresh_location) : null;
        if (refreshButton != null) {
            refreshButton.setEnabled(false);
        }
        
        // Request a single immediate location update
        fusedLocationClient.getCurrentLocation(LocationRequest.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener(location -> {
                if (location != null) {
                    updateLocationUI(location);
                } else {
                    currentLocationText.setText("Location unavailable");
                    coordinatesText.setText("Lat: --, Long: --");
                }
                // Hide progress indicator and re-enable button
                hideRefreshProgress();
            })
            .addOnFailureListener(e -> {
                currentLocationText.setText("Failed to get location");
                coordinatesText.setText("Error occurred");
                Toast.makeText(requireContext(), "Failed to refresh location: " + e.getMessage(), 
                    Toast.LENGTH_SHORT).show();
                // Hide progress indicator and re-enable button
                hideRefreshProgress();
            });
    }
    
    private void hideRefreshProgress() {
        if (progressRefreshLocation != null) {
            progressRefreshLocation.setVisibility(View.GONE);
        }
        // Re-enable the button
        View refreshButton = getView() != null ? getView().findViewById(R.id.btn_refresh_location) : null;
        if (refreshButton != null) {
            refreshButton.setEnabled(true);
        }
    }

    private void stopLocationUpdates() {
        if (locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }

    private void updateLocationUI(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();

        coordinatesText.setText(String.format(Locale.getDefault(),
                "Lat: %.4f, Long: %.4f", latitude, longitude));

        // Update the map if it's ready
        if (isMapReady && googleMap != null) {
            LatLng currentLocation = new LatLng(latitude, longitude);
            googleMap.clear(); // Clear previous markers
            googleMap.addMarker(new MarkerOptions().position(currentLocation).title("Current Location"));
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15f));
        }

        getAddressFromLocation(latitude, longitude);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        isMapReady = true;
        
        // Enable location on map if permission is granted
        if (ActivityCompat.checkSelfPermission(requireContext(), 
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        }
        
        // Customize map settings
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.getUiSettings().setCompassEnabled(true);
        googleMap.getUiSettings().setAllGesturesEnabled(true);
    }
    private void getAddressFromLocation(double latitude, double longitude) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Geocoder geocoder = new Geocoder(requireContext(), Locale.getDefault());

        executor.execute(() -> {
            try {
                List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                String locationName;

                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    String subLocality = address.getSubLocality() != null ? address.getSubLocality() : "";
                    String locality = address.getLocality() != null ? address.getLocality() : "";
                    locationName = (subLocality + ", " + locality).trim();
                    if (locationName.isEmpty()) {
                        locationName = "Unknown Location";
                    }
                } else {
                    locationName = "Location not found";
                }

                // ✅ Make it final for lambda
                final String finalLocationName = locationName;

                // Update UI on main thread
                requireActivity().runOnUiThread(() -> {
                    currentLocationText.setText(finalLocationName);
                });

            } catch (IOException e) {
                e.printStackTrace();
                // Update UI on main thread
                requireActivity().runOnUiThread(() -> {
                    currentLocationText.setText("Unable to get address");
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                Toast.makeText(requireContext(), "Location permission denied",
                        Toast.LENGTH_SHORT).show();
                currentLocationText.setText("Location permission denied");
                coordinatesText.setText("Please enable location permission in settings");
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mapView != null) {
            mapView.onResume();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        stopLocationUpdates();
        if (mapView != null) {
            mapView.onPause();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mapView != null) {
            mapView.onDestroy();
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapView != null) {
            mapView.onLowMemory();
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null) {
            mapView.onSaveInstanceState(outState);
        }
    }
}