package com.example.sosmate.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sosmate.MainActivity;
import com.example.sosmate.R;
import com.example.sosmate.database.DatabaseHelper;
import com.example.sosmate.models.LocationRecord;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.util.List;

public class LocationHistoryActivity extends AppCompatActivity {

    private FusedLocationProviderClient fusedLocationClient;
    private ImageButton backButton;
    private RecyclerView recyclerView;
    private DatabaseHelper databaseHelper;
    private LocationHistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_history);

        // Initialize UI and DB first
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        backButton = findViewById(R.id.backButton);
        recyclerView = findViewById(R.id.recyclerView);
        databaseHelper = DatabaseHelper.getInstance(this);

        if (backButton != null) {
            backButton.setOnClickListener(v -> navigateToHome());
        }

        // RecyclerView setup
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadLocationHistory();  // ✅ Safe now

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToHome();
            }
        });

        getCurrentLocation();
    }

    private void loadLocationHistory() {
        try {
            List<LocationRecord> locations = databaseHelper.getAllLocations();
            if (locations.isEmpty()) {
                Toast.makeText(this, "No location history found.", Toast.LENGTH_SHORT).show();
            } else {
                adapter = new LocationHistoryAdapter(locations);
                recyclerView.setAdapter(adapter);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load locations: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission required", Toast.LENGTH_LONG).show();
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                String msg = String.format("Current: %.4f, %.4f",
                        location.getLatitude(), location.getLongitude());
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Location unavailable", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateToHome() {
        Intent intent = new Intent(LocationHistoryActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}