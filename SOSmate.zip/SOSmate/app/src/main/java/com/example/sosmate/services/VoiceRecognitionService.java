package com.example.sosmate.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class VoiceRecognitionService extends Service {

    private static final String TAG = "VoiceRecognitionService";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "VoiceRecognitionService created");
        // TODO: Initialize voice recognition here
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "VoiceRecognitionService started");
        // TODO: Handle voice commands here
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "VoiceRecognitionService destroyed");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}